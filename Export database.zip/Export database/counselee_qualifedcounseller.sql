-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: counselee
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `qualifedcounseller`
--

DROP TABLE IF EXISTS `qualifedcounseller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qualifedcounseller` (
  `IDNO` int NOT NULL,
  `NAME` varchar(30) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `GENDER` varchar(10) DEFAULT NULL,
  `MOBNO` mediumtext,
  `ADDRESS` varchar(200) DEFAULT NULL,
  `EMAIL` varchar(30) DEFAULT NULL,
  `ACCNO` mediumtext,
  `FEILDCOU` varchar(20) DEFAULT NULL,
  `BESTCONTACT` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`IDNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qualifedcounseller`
--

LOCK TABLES `qualifedcounseller` WRITE;
/*!40000 ALTER TABLE `qualifedcounseller` DISABLE KEYS */;
INSERT INTO `qualifedcounseller` VALUES (1,'Rishita Patil','2002-03-04','FEMALE','4857639485','Amaravati','Rishita@Patil123','456738475629','Normal HealthCare','VIDEO CALL'),(2,'Rohit Dike','2000-02-03','MALE','3948357623','Amaravati','rohit@dike34gmail.com','293847565647','Psychology','VIDEO CALL'),(3,'Sneha Gore','2002-03-04','FEMALE','5675768475 ','Nagpur','Snehagore@23 ','567887655643 ','Covid','VIDEO CALL'),(4,'Rushi Rathee','2003-04-05','FEMALE','4857693847','Amaravati','Rushi@123','568794857631','Psychology','CALL');
/*!40000 ALTER TABLE `qualifedcounseller` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-05 20:02:44
